import React, { useState } from 'react'
import TodoItem from './components/TodoItem'

function App() {
  const [tasks, setTasks] = useState([])
  const [newTask, setNewTask] = useState('')

  const addTask = () => {
    if (newTask.trim() === '') return
    setTasks([...tasks, { text: newTask, completed: false }])
    setNewTask('')
  }

  const toggleTask = index => {
    const updatedTasks = [...tasks]
    updatedTasks[index].completed = !updatedTasks[index].completed
    setTasks(updatedTasks)
  }

  const removeTask = index => {
    const updatedTasks = tasks.filter((_, i) => i !== index)
    setTasks(updatedTasks)
  }

  return (
    <div className="app">
      <h1>To-Do List</h1>
      <div className="input-group">
        <input
          type="text"
          placeholder="Nova tarefa"
          value={newTask}
          onChange={e => setNewTask(e.target.value)}
        />
        <button onClick={addTask}>Adicionar</button>
      </div>
      <ul>
        {tasks.map((task, index) => (
          <TodoItem
            key={index}
            task={task}
            onToggle={() => toggleTask(index)}
            onRemove={() => removeTask(index)}
          />
        ))}
      </ul>
    </div>
  )
}

export default App
